#!/bin/bash

cd /var/www/html || exit

composer install

exec "$@"
